#undef static
#undef class
#undef namespace
#undef delete
}
