#include <wayland-server-core.h>

extern "C" {
#define static
#define class class_
#define namespace _namespace
#define delete delete_
