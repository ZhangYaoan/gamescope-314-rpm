#pragma once

#define VK_NO_PROTOTYPES
#include <vulkan/vulkan_core.h>
