#pragma once

namespace gamescope
{
    void PrintVersion();
}
