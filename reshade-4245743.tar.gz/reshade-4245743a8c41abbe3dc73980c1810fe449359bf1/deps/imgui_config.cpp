#include "imgui_config.hpp"

thread_local ImGuiContext *GImGuiThreadLocal = nullptr;
