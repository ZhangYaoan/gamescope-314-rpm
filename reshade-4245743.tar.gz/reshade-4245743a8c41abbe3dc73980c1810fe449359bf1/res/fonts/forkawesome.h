//Header Generated with https://github.com/aiekick/ImGuiFontStudio
//Based on https://github.com/juliettef/IconFontCppHeaders

#pragma once

#define FONT_ICON_BUFFER_NAME_FK FK_compressed_data_base85
#define FONT_ICON_BUFFER_SIZE_FK 0xc26

#define ICON_MIN_FK 0xf002
#define ICON_MAX_FK 0xf1c9

#define ICON_FK_CANCEL u8"\uf00d"
#define ICON_FK_FILE u8"\uf016"
#define ICON_FK_FILE_CODE u8"\uf1c9"
#define ICON_FK_FILE_IMAGE u8"\uf1c5"
#define ICON_FK_FLOPPY u8"\uf0c7"
#define ICON_FK_FOLDER u8"\uf114"
#define ICON_FK_FOLDER_OPEN u8"\uf115"
#define ICON_FK_MINUS u8"\uf068"
#define ICON_FK_OK u8"\uf00c"
#define ICON_FK_PENCIL u8"\uf040"
#define ICON_FK_PLUS u8"\uf067"
#define ICON_FK_REFRESH u8"\uf021"
#define ICON_FK_SEARCH u8"\uf002"
#define ICON_FK_UNDO u8"\uf0e2"
#define ICON_FK_WARNING u8"\uf071"
